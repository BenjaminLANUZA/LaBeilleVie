#include "mbed.h"
#include "DHT/DHT.h"
 
DigitalOut myled(LED1);
 
DHT dht(D8,DHT22);

float temperature;
float humidity;
 
int main() {
    int err;
    temperature = 0.0;
    humidity = 0.0;
    printf("\r\nDHT Test program");
    printf("\r\n******************\r\n");
    wait(1);
    while (1) {
        err = dht.readData(); //detecte si il y a des erreurs
        if (err == 0) {
            temperature = dht.ReadTemperature(CELCIUS);
            humidity = dht.ReadHumidity();
            printf("Temperature is %4.2f C \r\n",temperature);
            //printf("Temperature is %4.2f F \r\n",dht.ReadTemperature(FARENHEIT));
            //printf("Temperature is %4.2f K \r\n",dht.ReadTemperature(KELVIN));
            printf("Humidity is %4.2f \r\n",humidity);
            //printf("Dew point is %4.2f  \r\n",dht.CalcdewPoint(dht.ReadTemperature(CELCIUS), dht.ReadHumidity()));
            //printf("Dew point (fast) is %4.2f  \r\n",dht.CalcdewPointFast(dht.ReadTemperature(CELCIUS), dht.ReadHumidity()));
        } else
            printf("\r\nErr %i \n",err);
        wait(5);
    }
}
