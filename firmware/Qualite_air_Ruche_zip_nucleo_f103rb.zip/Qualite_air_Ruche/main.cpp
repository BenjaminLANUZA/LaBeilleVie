#include"mbed.h"
Serial pc(USBTX, USBRX);
AnalogIn analogPin(A0);
// Main loop
int main()
{
    while(1) {
        pc.printf("qualite air %d", (int)(analogPin.read() * 100));
        //entre 0 et 30 air frais
        //entre 30 et 70 air faible pollution
        //entre 70 et 100 air très polluée
        //renvoie tension entre 0 et 1V <=> concentration gazs polluants
    }
}
